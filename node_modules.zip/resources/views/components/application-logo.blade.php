<img src="{{ asset('assets/images/logo_trans.png') }}" alt="Logo" class="mx-auto" style="height: 130px;">
