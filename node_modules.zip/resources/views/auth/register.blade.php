<x-guest-layout>
    <form method="POST" action="{{ route('register') }}" x-data="{ tipo: '{{ old('tipo', 'candidato') }}' }">
        @csrf

        <!-- Tipo de usuário -->
        <div class="mt-4">
            <x-input-label for="tipo" value="Você é:" />
            <select id="tipo" name="tipo" class="block mt-1 w-full" x-model="tipo" required>
                <option value="candidato">Candidato</option>
                <option value="empresa">Empresa</option>
            </select>
            <x-input-error :messages="$errors->get('tipo')" class="mt-2" />
        </div>

        <!-- Nome (com label dinâmica segura usando Alpine) -->
        <div class="mt-4">
            <label class="block text-sm font-medium text-gray-700"
                x-text="tipo === 'empresa' ? 'Nome do Responsável' : 'Nome Completo'"></label>
            <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')"
                required autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>

        <!-- Email -->
        <div class="mt-4">
            <x-input-label for="email" value="Email" />
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')"
                required autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Telefone -->
        <div class="mt-4">
            <x-input-label for="telefone" value="Telefone" />
            <x-text-input id="telefone" class="block mt-1 w-full" type="text" name="telefone" :value="old('telefone')"
                required />
            <x-input-error :messages="$errors->get('telefone')" class="mt-2" />
        </div>

        <!-- CPF e Data de Nascimento (Candidato) -->
        <div class="mt-4" x-show="tipo === 'candidato'">
            <x-input-label for="cpf" value="CPF" />
            <x-text-input id="cpf" class="block mt-1 w-full" type="text" name="cpf" :value="old('cpf')" />
            <x-input-error :messages="$errors->get('cpf')" class="mt-2" />
        </div>

        <div class="mt-4" x-show="tipo === 'candidato'">
            <x-input-label for="data_nascimento" value="Data de Nascimento" />
            <x-text-input id="data_nascimento" class="block mt-1 w-full" type="date" name="data_nascimento"
                :value="old('data_nascimento')" />
            <x-input-error :messages="$errors->get('data_nascimento')" class="mt-2" />
        </div>

        <!-- CNPJ e Nome Fantasia (Empresa) -->
        <div class="mt-4" x-show="tipo === 'empresa'">
            <x-input-label for="cnpj" value="CNPJ" />
            <x-text-input id="cnpj" class="block mt-1 w-full" type="text" name="cnpj" :value="old('cnpj')" />
            <x-input-error :messages="$errors->get('cnpj')" class="mt-2" />
        </div>

        <div class="mt-4" x-show="tipo === 'empresa'">
            <x-input-label for="nome_fantasia" value="Nome da Empresa" />
            <x-text-input id="nome_fantasia" class="block mt-1 w-full" type="text" name="nome_fantasia"
                :value="old('nome_fantasia')" />
            <x-input-error :messages="$errors->get('nome_fantasia')" class="mt-2" />
        </div>

        <!-- CEP -->
        <div class="mt-4">
            <x-input-label for="cep" value="CEP" />
            <x-text-input id="cep" class="block mt-1 w-full" type="text" name="cep" :value="old('cep')"
                required />
            <x-input-error :messages="$errors->get('cep')" class="mt-2" />
        </div>

        <!-- Password -->
        <div class="mt-4">
            <x-input-label for="password" value="Senha" />
            <x-text-input id="password" class="block mt-1 w-full" type="password" name="password" required
                autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password -->
        <div class="mt-4">
            <x-input-label for="password_confirmation" value="Confirmar Senha" />
            <x-text-input id="password_confirmation" class="block mt-1 w-full" type="password"
                name="password_confirmation" required autocomplete="new-password" />
            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div>

        <!-- Botões -->
        <div class="flex items-center justify-end mt-4">
            <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('login') }}">
                Já tem conta?
            </a>

            <x-primary-button class="ml-4">
                Registrar
            </x-primary-button>
        </div>
    </form>
</x-guest-layout>
