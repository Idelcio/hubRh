<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{{ env('APP_NAME') }}</title>

    <!-- favicon -->
    <link rel="shortcut icon" href="{{ asset('assets/images/logo.jpg') }}" type="image/png" />

    <!-- bootstrap -->
    <link rel="stylesheet" href="{{ asset('assets/bootstrap/bootstrap.min.css') }}" />

    <!-- main css -->
    <link rel="stylesheet" href="{{ asset('assets/css/main.css') }}" />
</head>

<body style="background-color: rgb(1, 57, 131); min-height: 100vh;">
    <!-- Navbar simples -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                {{ env('APP_NAME', 'HubRH') }}
            </a>
            <div>
                <a class="btn btn-outline-light me-2" href="{{ route('login') }}">Login</a>
                <a class="btn btn-light" href="{{ route('register') }}">Registrar</a>
            </div>
        </div>
    </nav>
</body>
