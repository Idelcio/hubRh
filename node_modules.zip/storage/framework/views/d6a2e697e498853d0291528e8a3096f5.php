<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e(env('APP_NAME')); ?></title>

    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo.jpg')); ?>" type="image/png" />

    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap/bootstrap.min.css')); ?>" />

    <!-- main css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
</head>

<body style="background-color: rgb(1, 57, 131); min-height: 100vh;">
    <!-- Navbar simples -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(env('APP_NAME', 'HubRH')); ?>

            </a>
            <div>
                <a class="btn btn-outline-light me-2" href="<?php echo e(route('login')); ?>">Login</a>
                <a class="btn btn-light" href="<?php echo e(route('register')); ?>">Registrar</a>
            </div>
        </div>
    </nav>
</body>
<?php /**PATH C:\Users\Forest\Projetos\Laravel\hub\resources\views/home.blade.php ENDPATH**/ ?>